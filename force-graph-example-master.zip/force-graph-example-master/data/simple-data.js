export const data = {
    nodes:[{
        id:1,
        influence: 1
    },{
        id: 2,
        influence: 2
    }],
    links:[{
        source: 1,
        target: 2,
        weight: 3
    }]
};