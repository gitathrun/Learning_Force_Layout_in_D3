/**
 * Application root. Imports animate.js, which imports all relevant files.
 */
import './src/animate';
